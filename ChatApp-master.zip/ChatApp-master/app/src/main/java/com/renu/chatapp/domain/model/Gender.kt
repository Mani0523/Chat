package com.renu.chatapp.domain.model

enum class Gender {
  Male, Female
}