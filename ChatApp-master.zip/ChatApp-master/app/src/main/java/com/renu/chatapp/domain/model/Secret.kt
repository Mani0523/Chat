package com.renu.chatapp.domain.model

data class Secret (
    val svcAc : String
){
    constructor(): this("")
}